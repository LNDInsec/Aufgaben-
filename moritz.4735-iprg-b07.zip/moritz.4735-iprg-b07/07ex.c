/*
Zur Abgabe einen branch `iprg-b07` erstellen und pushen, in dem als einzige Datei die `07ex.c` liegt.
*/

/*
Um die Tests für dieses Blatt zu kompilieren und zu starten, führen Sie den folgenden Befehl aus:


Wir empfehlen, mit möglichst streng eingestelltem valgrind zu testen, denn so testen wir auch auf dem Server:
clang -std=c11 -g -Wall -Werror 07ex_test.c -o 07ex_test.o -lm && valgrind --leak-check=full --show-leak-kinds=all --track-origins=yes ./07ex_test.o
*/

#include "array_visualizer.h"
#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>

/*
Aufgabe 1:
Bringen Sie die Tests zum durchlaufen.

Tipp 1: Die erste Zeile im erzeugten Bild stellt das Eingabearray dar.
*/



void merge(uint8_t *arr,size_t left,size_t middle,size_t right,Visualizer *v) {
    size_t n1=middle-left+1; 
    size_t n2=right-middle;    
    uint8_t *L =(uint8_t*)malloc(n1*sizeof(uint8_t));
    uint8_t *R =(uint8_t*)malloc(n2*sizeof(uint8_t));

    for(size_t i =0;i < n1;i++){
        L[i] =arr[left + i];
    }
    for(size_t j = 0;j < n2;j++){
        R[j] =arr[middle + 1 + j];
    } 

    size_t i =0;
    size_t j =0;
    size_t k =left;
    while(i < n1&&j < n2){
        if (L[i] <=R[j]) {
            arr[k++] =L[i++];
        } else {
            arr[k++] = R[j++];
        }
    }
    while(i < n1){
        arr[k++] = L[i++];
    }
    while(j < n2){
        arr[k++] = R[j++];
    }
    visualizer_append_array(v,arr);
    free(L);
    free(R);
}
void mergesort(uint8_t *arr, size_t len, Visualizer *v) {
    size_t step = 1; 

    while(step < len){
        size_t left = 0; 

        while(left<len-step){
            size_t middle =left+step- 1;
            size_t right;
            if(left+2*step-1<len){
                right =left+2*step-1;
            } 
            else{
                right =len-1;
            }
            merge(arr,left,middle,right,v);
            left +=2*step;
        }
        step *=2;
    }
}
void sort_it(Visualizer *v, uint8_t *arr, size_t len) {
    visualizer_append_array(v,arr);
    mergesort(arr,len,v);
}
