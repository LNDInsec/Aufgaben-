/*
Zur Abgabe einen branch `iprg-b01` erstellen und pushen, in dem als einzige Datei die `01ex.c` liegt.
*/

/*
Um die Tests für dieses Blatt zu kompilieren und zu starten, führen Sie den folgenden Befehl aus:
clang -std=c11 -g -Wall -Werror 01ex_test.c -o 01ex_test.o -lm && ./01ex_test.o

Wir empfehlen, mit möglichst streng eingestelltem valgrind zu testen, denn so testen wir auch auf dem Server:
clang -std=c11 -g -Wall -Werror 01ex_test.c -o 01ex_test.o -lm && valgrind --leak-check=full --show-leak-kinds=all --track-origins=yes ./01ex_test.o
*/

#include "array_visualizer.h"
#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>

/*
Aufgabe 1:
Machen Sie sich in dieser Aufgabe mit dem `Visualizer` (siehe array_visualizer.h) vertraut.
Nutzen Sie die `visualizer_append_array` Funktion, um die Tests zum durchlaufen zu bringen.

Tipp 1: Die erste Zeile im erzeugten Bild stellt das Eingabearray dar.
Tipp 2: Jede weitere Zeile wird aus der Zeile davor durch eine einfache Modifikation gewonnen. Die Modifikation ist immer die gleiche.
*/
void warmup(Visualizer *v, uint8_t *arr, size_t len) {
    size_t c =0;
    uint8_t modifizierter_array[len];
    while(c<len){
        modifizierter_array[c]=arr[c];
        c++;
    }
    visualizer_append_array(v,modifizierter_array);
        size_t a=0;
        while(a<len){
            modifizierter_array[a]=arr[0];
            for(size_t b=len;b>a;b--){
                modifizierter_array[b]=modifizierter_array[b-1];//Den Rest nach Rechts verschieben
            }
            visualizer_append_array(v,modifizierter_array);
            a++;

        }
       
         
}

/*
Aufgabe 2:
Bringen Sie die Tests zum durchlaufen.

Tipp: Die erste Zeile im erzeugten Bild stellt das Eingabearray dar.
*/
void sort_it(Visualizer *v, uint8_t *arr, size_t len) {
    int a = 0;
    while (a < len){
        int b;
        int key = arr[a]; 
        b = a - 1; 
        while (b >= 0 && arr[b] > key){
            arr[b+1] = arr[b]; 
            b--;
        }
        arr[b+1] = key; 
        a++;
        visualizer_append_array(v,arr);
    }
    
    
}
